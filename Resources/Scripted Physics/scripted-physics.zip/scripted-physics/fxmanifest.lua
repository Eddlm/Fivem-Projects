fx_version 'adamant'
games { 'gta5' }

author 'Eddlm'
name 'Scripted Physics'
description 'Enhances physics by scripting some. Home of Custom Wheelies and Inverse Torque, full featureset on GitHub (github.com/Eddlm).'
version '0.1.0 (Public - GitHub)'
url 'https://github.com/Eddlm'

client_script 'client/ScriptedPhysics.net.dll';
server_script 'server/ScriptedPhysicsServer.net.dll';
